export interface IBook {
  BookId: number;

  BookName: string;

  AuthorName: string;

  BookUrl: string;

  FrontPageUrl: string;

  Price: string;
}
