export interface ICart {
  cartId: number;

  userId: string;

  bookId: string;

  ratings: string;
}
