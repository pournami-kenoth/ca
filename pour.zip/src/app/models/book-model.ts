// export class Book{
//     bookId:number;
//     title: string;
//     price: number;
//     coverFileName: string;
//     Discription:string;
//     price:number;
//     author:string;
// }