// import { ShoppingCart } from './shoppingcart-model';

// export class Order {
//     orderDetails: ShoppingCart[] = [];
//     cartTotal: number;
//     orderId: string;
//     orderDate: Date;
// }