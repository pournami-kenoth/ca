// import { Book } from './book-model';

// export class ShoppingCart {
//     book: Book;
//     quantity: number;
// }
