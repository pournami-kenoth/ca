// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import {Book} from '../models/book-model';

// @Injectable({
//   providedIn: 'root'
// })
// export class UserService {
//     baseURL: 'https://localhost:44336/';

//   constructor(private http: HttpClient) {
//   }

//   registerUser(userdetails: any) {
//     return this.http.post(this.baseURL+'/api/Account/SignUp', userdetails);
//   }

//   login(userdetails:any) {
//     return this.http.get<Book>(this.baseURL+"/api/Account/Login");
//   }

// }
