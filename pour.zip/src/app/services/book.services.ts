// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { shareReplay, map } from 'rxjs/operators';
// import { Book } from '../models/book-model';


// @Injectable({
//   providedIn: 'root'
// })
// export class BookService {

//   baseURL = '/api/book/';

//   constructor(private http: HttpClient) { }

//   baseUrl='https://localhost:44336/';


//   GetBestSeller() {
//     return this.http.get<Book[]>(this.baseURL+'/api/Book/GetBestSellerBooks');
//   }
//   GetTrendingSeller() {
//     return this.http.get<Book[]>(this.baseURL+'/api/Book/GetTrendingBooks');
//   }
//   GetLatestSeller() {
//     return this.http.get<Book[]>(this.baseURL+'/api/Book/GetLatestBooks');
//   }

//   addBook(book: any) {
//     return this.http.post(this.baseURL+'/api/Book/Upload', book);
//   }

//   getBookById(id: number) {
//     return this.books.pipe(map(book => book.find(b => b.bookId === id)));
//   }

//   getsimilarBooks(bookId: number) {
//     return this.http.get<Book[]>(this.baseURL + 'GetSimilarBooks/' + bookId);
//   }

//   updateBookDetails(book: any) {
//     return this.http.put(this.baseURL+'', book);
//   }

//   deleteBook(id: number) {
//     return this.http.delete(this.baseURL + id);
//   }
// }
