import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './User/login/login.component';
import { RegisterComponent } from './User/register/register.component';
import {HomeComponent} from './home/home.component';
import { BookStoreComponent } from './book-store/book-store.component';
import { CartComponent} from './cart/cart.component';
import { BookComponent } from './books/books.component';
import {BookDetailsComponent} from './books/book-details/book-details.component'

const routes: Routes = [
  {path:'Login', component:LoginComponent},
  {path:'Home', component:HomeComponent},
  {path:'Register',component:RegisterComponent},
  {path:'BookStore',component:BookStoreComponent},
  {path:'Cart', component:CartComponent},
  {path:'Bookdetails',component:BookComponent},
  {path:'addBooks',component:BookDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
