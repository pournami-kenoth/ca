import { Component, OnInit } from '@angular/core';
// import { Book } from 'src/app/models/book-model';
// import { BookService } from 'src/app/services/book.services';
import { ActivatedRoute } from '@angular/router';
import { EMPTY, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
// import { User } from 'src/app/models/user-models';



@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BookComponent implements OnInit {
  ngOnInit(): void {
    
  }

}