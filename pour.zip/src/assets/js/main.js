$(function() {

	// TOOLTIPS
	$('[data-toggle="tooltip"]').tooltip();

	$('.specific-tip').tooltip({
		html: true,
  		placement: 'bottom',
  		trigger: 'click'
	});

	// POPOVERS
	$('[data-toggle="popover"]').popover();

	// DYNAMIC POPOVER
	const getAttr = (el, child) => {
  		return $(`.data-${child}`, $(el).attr('data-bind')).html();
	};

	$('.dynamic-popover').popover({
  		html: true,
  		placement: 'bottom',
  		title: function () {
    		return getAttr(this, 'title');
  		},
  		content: function () {
    		return getAttr(this, 'content');
  		}
	});


	// ACCOUNT MODAL VARIATIONS
	$('#account-modal').on('show.bs.modal', function (event) {
  		var $button = $(event.relatedTarget);
  		var $case = $button.data('case');
  		var $modal = $(this);

  		if($case == "register") {
  			$modal.find('#login-case').hide();
  			$modal.find('#register-case').show();
  		} else {
  			$modal.find('#register-case').hide();
  			$modal.find('#login-case').show();
  		}
	});


});
$document.ready(function(){

	$('.items').slick({
	dots: true,
	infinite: true,
	speed: 800,
	autoplay: true,
	autoplaySpeed: 2000,
	slidesToShow: 4,
	slidesToScroll: 4,
	responsive: [
	{
	breakpoint: 1024,
	settings: {
	slidesToShow: 3,
	slidesToScroll: 3,
	infinite: true,
	dots: true
	}
	},
	{
	breakpoint: 600,
	settings: {
	slidesToShow: 2,
	slidesToScroll: 2
	}
	},
	{
	breakpoint: 480,
	settings: {
	slidesToShow: 1,
	slidesToScroll: 1
	}
	}
	
	]
	});
	});
	// $('.file-upload').file_upload();